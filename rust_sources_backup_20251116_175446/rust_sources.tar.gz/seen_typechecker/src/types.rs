//! Type definitions for the Seen type system
//!
//! Implements nullable-by-default types with compile-time safety.
//! All types support generics and smart-casting after null checks.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Represents a type in the Seen language
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Type {
    /// Primitive integer type
    Int,
    /// Primitive unsigned integer type
    UInt,
    /// Primitive floating-point type
    Float,
    /// Primitive boolean type
    Bool,
    /// Primitive string type
    String,
    /// Primitive character type
    Char,
    /// Array type with element type
    Array(Box<Type>),
    /// Map/HashMap type with key and value types
    Map {
        key_type: Box<Type>,
        value_type: Box<Type>,
    },
    /// Nullable type (all types can be nullable)
    Nullable(Box<Type>),
    /// Function type with parameter types and return type
    Function {
        params: Vec<Type>,
        return_type: Box<Type>,
        is_async: bool,
    },
    /// User-defined struct type
    Struct {
        name: String,
        fields: HashMap<String, Type>,
        generics: Vec<Type>,
    },
    /// User-defined enum type
    Enum {
        name: String,
        variants: Vec<String>,
        generics: Vec<Type>,
    },
    /// Interface/trait type
    Interface {
        name: String,
        methods: Vec<String>,
        generics: Vec<Type>,
        is_sealed: bool,
    },
    /// Task handle type with result payload
    Task(Box<Type>),
    /// Generic type parameter
    Generic(String),
    /// Unit/void type
    Unit,
    /// Diverging type (never returns)
    Never,
    /// Unknown type (for inference)
    Unknown,
    /// Error type (for error recovery)
    Error,
}

impl Type {
    /// Check if this type is primitive
    pub fn is_primitive(&self) -> bool {
        matches!(
            self,
            Type::Int | Type::UInt | Type::Float | Type::Bool | Type::String | Type::Char
        )
    }

    /// Check if this type is numeric
    pub fn is_numeric(&self) -> bool {
        matches!(self, Type::Int | Type::UInt | Type::Float)
    }

    /// Check if this type is nullable
    pub fn is_nullable(&self) -> bool {
        matches!(self, Type::Nullable(_))
    }

    /// Get the non-nullable version of this type
    pub fn non_nullable(&self) -> &Type {
        match self {
            Type::Nullable(inner) => inner.non_nullable(),
            other => other,
        }
    }

    /// Get the underlying type if this is nullable
    pub fn unwrap_nullable(&self) -> Option<&Type> {
        match self {
            Type::Nullable(inner) => Some(inner),
            _ => None,
        }
    }

    /// Make this type nullable
    pub fn nullable(self) -> Type {
        if self.is_nullable() {
            self
        } else {
            Type::Nullable(Box::new(self))
        }
    }

    /// Check if this type supports a specific operation
    pub fn supports_operation(&self, op: &str) -> bool {
        if matches!(self, Type::Never) {
            return true;
        }

        match self.non_nullable() {
            Type::Int => matches!(
                op,
                "+" | "-"
                    | "*"
                    | "/"
                    | "%"
                    | "<"
                    | ">"
                    | "<="
                    | ">="
                    | "=="
                    | "!="
                    | "&"
                    | "|"
                    | "^"
                    | "<<"
                    | ">>"
            ),
            Type::UInt => matches!(
                op,
                "+" | "-"
                    | "*"
                    | "/"
                    | "%"
                    | "<"
                    | ">"
                    | "<="
                    | ">="
                    | "=="
                    | "!="
                    | "&"
                    | "|"
                    | "^"
                    | "<<"
                    | ">>"
            ),
            Type::Float => matches!(
                op,
                "+" | "-" | "*" | "/" | "%" | "<" | ">" | "<=" | ">=" | "==" | "!="
            ),
            Type::String => {
                // Permit String + any (toString at codegen), and comparisons
                matches!(op, "+" | "==" | "!=" | "<" | ">" | "<=" | ">=")
            }
            Type::Bool => {
                matches!(op, "and" | "or" | "not" | "==" | "!=")
            }
            Type::Array(_) => {
                matches!(op, "[]" | "==" | "!=")
            }
            _ => false,
        }
    }

    /// Get the result type of a binary operation
    pub fn binary_operation_result(&self, op: &str, other: &Type) -> Option<Type> {
        if matches!(self, Type::Never) || matches!(other, Type::Never) {
            return Some(Type::Never);
        }

        // Handle nullable operands
        let (left, right) = (self.non_nullable(), other.non_nullable());
        let result_nullable = self.is_nullable() || other.is_nullable();

        let result = match (left, op, right) {
            // Arithmetic operations
            (Type::Int, "+" | "-" | "*" | "/" | "%", Type::Int) => Some(Type::Int),
            (Type::UInt, "+" | "-" | "*" | "/" | "%", Type::UInt) => Some(Type::UInt),
            (Type::Float, "+" | "-" | "*" | "/" | "%", Type::Float) => Some(Type::Float),
            (Type::Int, "+" | "-" | "*" | "/" | "%", Type::Float) => Some(Type::Float),
            (Type::Float, "+" | "-" | "*" | "/" | "%", Type::Int) => Some(Type::Float),
            (Type::UInt, "+" | "-" | "*" | "/" | "%", Type::Int) => Some(Type::Int),
            (Type::UInt, "+" | "-" | "*" | "/" | "%", Type::Float) => Some(Type::Float),

            // Bitwise operations (integers only)
            (Type::Int, "&" | "|" | "^", Type::Int) => Some(Type::Int),
            (Type::Int, "&" | "|" | "^", Type::UInt) => Some(Type::Int),
            (Type::UInt, "&" | "|" | "^", Type::Int) => Some(Type::Int),
            (Type::UInt, "&" | "|" | "^", Type::UInt) => Some(Type::UInt),

            // Shift operations
            (Type::Int, "<<" | ">>", Type::Int) => Some(Type::Int),
            (Type::Int, "<<" | ">>", Type::UInt) => Some(Type::Int),
            (Type::UInt, "<<" | ">>", Type::Int) => Some(Type::UInt),
            (Type::UInt, "<<" | ">>", Type::UInt) => Some(Type::UInt),

            // String concatenation
            (Type::String, "+", Type::String) => Some(Type::String),

            // Allow string concatenation with Unknown types (assumes toString conversion)
            (Type::String, "+", Type::Unknown) => Some(Type::String),
            (Type::Unknown, "+", Type::String) => Some(Type::String),

            // Comparison operations
            (Type::Int, "<" | ">" | "<=" | ">=" | "==" | "!=", Type::Int) => Some(Type::Bool),
            (Type::UInt, "<" | ">" | "<=" | ">=" | "==" | "!=", Type::UInt) => Some(Type::Bool),
            (Type::Float, "<" | ">" | "<=" | ">=" | "==" | "!=", Type::Float) => Some(Type::Bool),
            (Type::String, "<" | ">" | "<=" | ">=" | "==" | "!=", Type::String) => Some(Type::Bool),

            // Logical operations
            (Type::Bool, "and" | "or", Type::Bool) => Some(Type::Bool),

            // String + any coerces to String
            (Type::String, "+", _) => Some(Type::String),
            (_, "+", Type::String) => Some(Type::String),

            // Equality for any type - allow comparing same types even if one is nullable
            (a, "==" | "!=", b) if a == b => Some(Type::Bool),

            // Enum comparisons - enums of the same type can be compared with any operator
            (Type::Enum { name: n1, .. }, "<" | ">" | "<=" | ">=", Type::Enum { name: n2, .. })
            if n1 == n2 =>
                {
                    Some(Type::Bool)
                }

            // Allow comparing nullable with its base type
            (Type::Nullable(inner), "==" | "!=", b) if inner.as_ref() == b => Some(Type::Bool),
            (a, "==" | "!=", Type::Nullable(inner)) if a == inner.as_ref() => Some(Type::Bool),

            // Allow comparing different nullable types if their inner types match
            (Type::Nullable(a_inner), "==" | "!=", Type::Nullable(b_inner))
            if a_inner.as_ref() == b_inner.as_ref() =>
                {
                    Some(Type::Bool)
                }

            // Allow comparisons with Unknown types (for type inference in progress)
            (Type::Unknown, "==" | "!=" | "<" | ">" | "<=" | ">=", _) => Some(Type::Bool),
            (_, "==" | "!=" | "<" | ">" | "<=" | ">=", Type::Unknown) => Some(Type::Bool),

            // Allow arithmetic/logical operations with Unknown types
            (Type::Unknown, "+" | "-" | "*" | "/" | "%", _) => Some(Type::Unknown),
            (_, "+" | "-" | "*" | "/" | "%", Type::Unknown) => Some(Type::Unknown),
            (Type::Unknown, "and" | "or", _) => Some(Type::Bool),
            (_, "and" | "or", Type::Unknown) => Some(Type::Bool),

            _ => None,
        }?;

        Some(if result_nullable && result != Type::Bool {
            result.nullable()
        } else {
            result
        })
    }

    /// Returns true if this represents a diverging code path
    pub fn is_never(&self) -> bool {
        matches!(self, Type::Never)
    }

    /// Returns true if this behaves like the Unit/Void type (including nullable forms)
    pub fn is_unit_like(&self) -> bool {
        match self {
            Type::Unit => true,
            Type::Struct { name, .. } if name == "Void" => true,
            Type::Nullable(inner) => inner.is_unit_like(),
            _ => false,
        }
    }

    /// Helper constructors for common types
    pub fn int() -> Type {
        Type::Int
    }
    pub fn uint() -> Type {
        Type::UInt
    }
    pub fn float() -> Type {
        Type::Float
    }
    pub fn bool() -> Type {
        Type::Bool
    }
    pub fn string() -> Type {
        Type::String
    }
    pub fn char() -> Type {
        Type::Char
    }
    pub fn unit() -> Type {
        Type::Unit
    }
    pub fn error() -> Type {
        Type::Error
    }

    /// Check if two types are compatible for assignment
    pub fn is_assignable_to(&self, other: &Type) -> bool {
        if self.is_unit_like() && other.is_unit_like() {
            return true;
        }

        match (self, other) {
            (Type::Never, _) => true,
            (_, Type::Never) => matches!(self, Type::Never),
            (Type::Generic(_), _) => true,
            (_, Type::Generic(_)) => true,
            // Exact match
            (a, b) if a == b => true,

            // Int can be assigned to Float
            (Type::Int, Type::Float) => true,

            // Any type can be assigned to its nullable version
            (inner, Type::Nullable(opt_inner)) => inner.is_assignable_to(opt_inner),

            // Array types must have compatible element types
            (Type::Array(a), Type::Array(b)) => a.is_assignable_to(b),

            // Map types must have compatible key and value types
            (
                Type::Map {
                    key_type: k1,
                    value_type: v1,
                },
                Type::Map {
                    key_type: k2,
                    value_type: v2,
                },
            ) => k1.is_assignable_to(k2) && v1.is_assignable_to(v2),

            // Task types must agree on payload
            (Type::Task(a), Type::Task(b)) => a.is_assignable_to(b),

            // Function types must have compatible signatures
            (
                Type::Function {
                    params: p1,
                    return_type: r1,
                    ..
                },
                Type::Function {
                    params: p2,
                    return_type: r2,
                    ..
                },
            ) => {
                p1.len() == p2.len()
                    && p1.iter().zip(p2).all(|(a, b)| a.is_assignable_to(b))
                    && r1.is_assignable_to(r2)
            }

            (
                Type::Struct {
                    name: n1,
                    generics: g1,
                    ..
                },
                Type::Struct {
                    name: n2,
                    generics: g2,
                    ..
                },
            ) => {
                n1 == n2
                    && g1.len() == g2.len()
                    && g1.iter().zip(g2).all(|(a, b)| a.is_assignable_to(b))
            }

            (
                Type::Enum {
                    name: n1,
                    generics: g1,
                    ..
                },
                Type::Enum {
                    name: n2,
                    generics: g2,
                    ..
                },
            ) => {
                n1 == n2
                    && g1.len() == g2.len()
                    && g1.iter().zip(g2).all(|(a, b)| a.is_assignable_to(b))
            }

            (
                Type::Interface {
                    name: n1,
                    generics: g1,
                    ..
                },
                Type::Interface {
                    name: n2,
                    generics: g2,
                    ..
                },
            ) => {
                n1 == n2
                    && g1.len() == g2.len()
                    && g1.iter().zip(g2).all(|(a, b)| a.is_assignable_to(b))
            }

            // Unknown type is compatible with anything (for inference)
            (Type::Unknown, _) | (_, Type::Unknown) => true,

            _ => false,
        }
    }

    /// Get a human-readable name for this type
    pub fn name(&self) -> String {
        match self {
            Type::Int => "Int".to_string(),
            Type::UInt => "UInt".to_string(),
            Type::Float => "Float".to_string(),
            Type::Bool => "Bool".to_string(),
            Type::String => "String".to_string(),
            Type::Char => "Char".to_string(),
            Type::Array(inner) => format!("Array<{}>", inner.name()),
            Type::Map {
                key_type,
                value_type,
            } => {
                format!("Map<{}, {}>", key_type.name(), value_type.name())
            }
            Type::Nullable(inner) => format!("{}?", inner.name()),
            Type::Unit => "Unit".to_string(),
            Type::Never => "Never".to_string(),
            Type::Function {
                params,
                return_type,
                ..
            } => {
                let param_names: Vec<String> = params.iter().map(|p| p.name()).collect();
                format!("({}) -> {}", param_names.join(", "), return_type.name())
            }
            Type::Struct { name, generics, .. } => {
                if generics.is_empty() {
                    name.clone()
                } else {
                    let args: Vec<String> = generics.iter().map(|g| g.name()).collect();
                    format!("{}<{}>", name, args.join(", "))
                }
            }
            Type::Enum { name, generics, .. } => {
                if generics.is_empty() {
                    name.clone()
                } else {
                    let args: Vec<String> = generics.iter().map(|g| g.name()).collect();
                    format!("{}<{}>", name, args.join(", "))
                }
            }
            Type::Interface { name, generics, .. } => {
                if generics.is_empty() {
                    name.clone()
                } else {
                    let args: Vec<String> = generics.iter().map(|g| g.name()).collect();
                    format!("{}<{}>", name, args.join(", "))
                }
            }
            Type::Task(inner) => format!("Task<{}>", inner.name()),
            Type::Generic(name) => name.clone(),
            Type::Unknown => "?".to_string(),
            Type::Error => "Error".to_string(),
        }
    }
}

impl std::fmt::Display for Type {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.name())
    }
}

/// Type information attached to AST nodes
#[derive(Debug, Clone, PartialEq)]
pub struct TypeInfo {
    /// The resolved type
    pub resolved_type: Type,
    /// Whether this type was inferred or explicitly specified
    pub inferred: bool,
}

impl TypeInfo {
    /// Create type info for an explicitly specified type
    pub fn explicit(t: Type) -> Self {
        Self {
            resolved_type: t,
            inferred: false,
        }
    }

    /// Create type info for an inferred type
    pub fn inferred(t: Type) -> Self {
        Self {
            resolved_type: t,
            inferred: true,
        }
    }
}

/// Convert from parser AST types to type checker types
impl From<&seen_parser::ast::Type> for Type {
    fn from(ast_type: &seen_parser::ast::Type) -> Self {
        // Primitive types
        let base_type = match ast_type.name.as_str() {
            "Int" => Type::Int,
            "UInt" => Type::UInt,
            "Float" => Type::Float,
            "Bool" => Type::Bool,
            "String" => Type::String,
            "Char" => Type::Char,
            "Void" | "()" | "Unit" => Type::Unit,
            _ => {
                // Single-letter uppercase identifiers are treated as generics by convention
                if ast_type.generics.is_empty()
                    && ast_type.name.len() == 1
                    && ast_type
                        .name
                        .chars()
                        .next()
                        .map(|c| c.is_ascii_uppercase())
                        .unwrap_or(false)
                {
                    Type::Generic(ast_type.name.clone())
                } else {
                    let mut resolved_generics: Vec<Type> =
                        ast_type.generics.iter().map(Type::from).collect();

                    match ast_type.name.as_str() {
                        "Array" | "List" | "Vec" if !resolved_generics.is_empty() => {
                            Type::Array(Box::new(resolved_generics.remove(0)))
                        }
                        "Map" | "HashMap" if resolved_generics.len() >= 2 => Type::Map {
                            key_type: Box::new(resolved_generics.remove(0)),
                            value_type: Box::new(resolved_generics.remove(0)),
                        },
                        _ => Type::Struct {
                            name: ast_type.name.clone(),
                            fields: HashMap::new(),
                            generics: resolved_generics,
                        },
                    }
                }
            }
        };

        if ast_type.is_nullable {
            Type::Nullable(Box::new(base_type))
        } else {
            base_type
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_type_compatibility() {
        assert!(Type::Int.is_assignable_to(&Type::Int));
        assert!(Type::Int.is_assignable_to(&Type::Float));
        assert!(!Type::Float.is_assignable_to(&Type::Int));
        assert!(Type::String.is_assignable_to(&Type::Nullable(Box::new(Type::String))));
    }

    #[test]
    fn test_type_names() {
        assert_eq!(Type::Int.name(), "Int");
        assert_eq!(Type::Array(Box::new(Type::String)).name(), "Array<String>");
        assert_eq!(Type::Nullable(Box::new(Type::Int)).name(), "Int?");
    }
}
